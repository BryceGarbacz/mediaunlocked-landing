import React from "react";

export default function LandingPage() {
  return (
    <div className="bg-white text-gray-900">
      <section className="text-center py-20 px-4 max-w-5xl mx-auto">
        <h1 className="text-4xl font-bold mb-4">Affordable Websites Built for Service Businesses</h1>
        <p className="text-lg mb-6">
          No retainers. Just results. Convert leads with streamlined booking and payment solutions.
        </p>
        <a href="#contact" className="bg-blue-600 text-white px-6 py-3 rounded text-lg">Get a Free Quote</a>
      </section>

      <section className="bg-gray-50 py-16 px-4 max-w-6xl mx-auto">
        <h2 className="text-2xl font-semibold text-center mb-10">What We Offer</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {['Custom Web Design', 'Booking & Payment Integration', 'Mobile Optimization', 'SEO-Friendly Setup'].map(service => (
            <div key={service} className="p-6 border rounded text-center bg-white">
              <h3 className="font-medium text-lg mb-2">{service}</h3>
              <p className="text-sm text-gray-600">Tailored to your business needs.</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-16 px-4 max-w-5xl mx-auto">
        <h2 className="text-2xl font-semibold text-center mb-10">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          {[
            { step: "Step 1", title: "Get a Free Quote" },
            { step: "Step 2", title: "We Build Your Site" },
            { step: "Step 3", title: "You Launch & Grow" }
          ].map(({ step, title }) => (
            <div key={step}>
              <div className="text-xl font-bold mb-2">{step}</div>
              <p className="text-lg">{title}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-gray-100 py-16 px-4 max-w-5xl mx-auto text-center">
        <h2 className="text-2xl font-semibold mb-10">Why Choose MediaUnlocked?</h2>
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-6 text-lg">
          <li>No Monthly Retainers</li>
          <li>Built for Conversions</li>
          <li>Fast Turnaround</li>
          <li>Trusted by 200+ Clients</li>
        </ul>
      </section>

      <section className="py-20 px-4 text-center" id="contact">
        <h2 className="text-3xl font-bold mb-4">Let’s Build Your Website</h2>
        <p className="mb-6 text-lg">Start converting leads today with a powerful online presence.</p>
        <a href="mailto:info@mediaunlocked.com" className="bg-blue-600 text-white px-6 py-3 rounded text-lg">Get a Free Quote</a>
      </section>

      <footer className="bg-gray-800 text-white py-6 text-center">
        <p>© {new Date().getFullYear()} MediaUnlocked LLC. All rights reserved.</p>
      </footer>
    </div>
  );
}